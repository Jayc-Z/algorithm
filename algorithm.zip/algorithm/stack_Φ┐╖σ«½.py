# 迷宫问题
# 回溯法（但不一定是最短路径）深度优先搜索
# 1、按照“上、右、下、左”的顺序寻找下一条路
# 2、如果能找到则进栈，找不到则出栈并回退

maze = [
    [1,1,1,1,1,1,1,1,1,1],
    [1,0,0,1,0,0,0,1,0,1],
    [1,0,0,1,0,0,0,1,0,1],
    [1,0,0,0,0,1,1,0,0,1],
    [1,0,1,1,1,0,0,0,0,1],
    [1,0,0,0,1,0,0,0,0,1],
    [1,0,1,0,0,0,1,0,0,1],
    [1,0,1,1,1,0,1,1,0,1],
    [1,1,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1]
]

dirs = [
    lambda x,y: (x+1, y),
    lambda x,y: (x-1, y),
    lambda x,y: (x, y+1),
    lambda x,y: (x, y-1)
]

def maze_path(x1, y1, x2, y2):
    '''
    :param x1: start x axis position
    :param y1: start y axis position
    :param x2: end x axis position
    :param y2: end y axis position
    :return: path
    '''
    stack = []
    stack.append((x1, y1))
    while len(stack) > 0:
        curNode = stack[-1]
        if curNode[0] == x2 and curNode[1] == y2:
            for p in stack:
                print(p)
            return True
        for dir in dirs:
            nextNode = dir(curNode[0], curNode[1])
            if maze[nextNode[0]][nextNode[1]] == 0:
                stack.append(nextNode)
                maze[nextNode[0]][nextNode[1]] = 2 # 不走回头路
                break
        else:
            maze[nextNode[0]][nextNode[1]] = 2
            stack.pop()
    else:
        print("no path")
        return False

x1, y1 = 1, 1
x2, y2 = 8, 8
maze_path(x1, y1, x2, y2)