from collections import deque

q = deque()
# 单向队列
# q.append(1) # 队尾进队
# q.popleft() # 队首出队

# 双向队列
# q.appendleft(1) # 队首进队
# q.pop()   # 队尾出队

# 打印文件后五行
def tail(n):
    with open("queue_test.txt", "r", encoding="utf-8") as fr:
        q = deque(fr,n)
        return q

print(tail(5))