 # 环形队列 当队尾指针front == maxsize + 1时，再前进一个位置就自动到0
    # 队首指针前进1: front = （front + 1）% maxsize
    # 队尾指针前进1: rear = （rear + 1）% maxsize
    # 队空条件：front = rear
    # 队满条件：（rear + 1）% maxsize = front

class Queue:
    def __init__(self, size=100):
        self.queue = [0 for _ in range(size)]
        self.front = 0 # 队首
        self.rear = 0 # 队尾
        self.max_size = size

    def push(self, x):
        if not self.is_full():
            self.rear = (self.rear + 1) % self.max_size
            self.queue[self.rear] = x
        else:
            raise IndexError("Queue is full")

    def pop(self):
        if not self.is_empty():
            self.front = (self.front + 1) % self.max_size
            return self.queue[self.front]
        else:
            raise IndexError("Queue is empty")

    def is_empty(self):
        return self.front == self.rear

    def is_full(self):
        return (self.rear + 1) % self.max_size == self.front

q = Queue()
for i in range(99):
    q.push(i)
print(q.is_full())
