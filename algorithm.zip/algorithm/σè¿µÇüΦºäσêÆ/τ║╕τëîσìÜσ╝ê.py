'''
题目描述：
有一个整型数组A，代表数值不同的纸牌排成一条线。玩家a和玩家b依次拿走每张纸牌，规定玩家a先拿，玩家B后拿，
但是每个玩家每次只能拿走最左或最右的纸 牌，玩家a和玩家b都绝顶聪明，他们总会采用最优策略。请返回最后获胜者的分数。
给定纸牌序列A及序列的大小n，请返回最后分数较高者得分数(相同则返回任意一个分数)。保证A中的元素均小于等于1000。且A的大小小于等于300。
'''
'''
[20, 2, 100, 40]
'''

# 1.暴力递归
class Solution:
    def process(self, arr):
        if len(arr) == 0:
            return 0
        first = self.f(arr, 0, len(arr) - 1)
        second = self.g(arr, 0, len(arr) - 1)
        return max(first, second)
    # 先手拿到的最好分数
    def f(self, arr, L, R):
        if L == R:
            return arr[L]
        p1 = arr[R] + self.g(arr, L, R-1)
        p2 = arr[L] + self.g(arr, L+1, R)
        return max(p1, p2)

    # 后手拿到的最好分数
    def g(self, arr, L, R):
        if L == R:
            return 0
        p1 = self.f(arr, L+1, R)
        p2 = self.f(arr, L, R-1)
        return min(p1, p2)     # 先手一定会留下较小值

# 2.傻缓存
class Solution2:
    def process(self, arr):
        n = len(arr)
        ### 由于f依赖g，而g又依赖f，因此需要两张dp表
        fmap = [[-1 for _ in range(n)] for _ in range(n)]
        gmap = [[-1 for _ in range(n)] for _ in range(n)]
        if len(arr) == 0:
            return 0
        first = self.f(arr, 0, len(arr) - 1, fmap, gmap)
        second = self.g(arr, 0, len(arr) - 1, fmap, gmap)
        return max(first, second)
    # 先手拿到的最好分数
    def f(self, arr, L, R, fmap, gmap):
        if fmap[L][R] != -1:
            return fmap[L][R]
        ans = 0
        if L == R:
            ans = arr[L]
        else:
            p1 = arr[R] + self.g(arr, L, R-1, fmap, gmap)
            p2 = arr[L] + self.g(arr, L+1, R, fmap, gmap)
            ans = max(p1, p2)
        fmap[L][R] = ans
        return ans

    # 后手拿到的最好分数
    def g(self, arr, L, R, fmap, gmap):
        if gmap[L][R] != -1:
            return gmap[L][R]
        ans = 0
        if L != R:
            p1 = self.f(arr, L+1, R, fmap, gmap)
            p2 = self.f(arr, L, R-1, fmap, gmap)
            ans = min(p1, p2)     # 先手一定会留下较小值
        gmap[L][R] = ans
        return ans

# 3.dp
class Solution3:
    def process(self, arr):
        if len(arr) == 0:
            return 0
        n = len(arr)
        ### 由于f依赖g，而g又依赖f，因此需要两张dp表
        fmap = [[0 for _ in range(n)] for _ in range(n)]
        gmap = [[0 for _ in range(n)] for _ in range(n)]
        for i in range(n):
            fmap[i][i] = arr[i]
        for Startcol in range(1, n):  # 按斜对角线依次推数
            L = 0
            R = Startcol
            while R <= n-1:
                fmap[L][R] = max(arr[R] + gmap[L][R-1], arr[L] + gmap[L+1][R])
                gmap[L][R] = min(fmap[L+1][R], fmap[L][R-1])
                L += 1
                R += 1
        print(fmap)
        print(gmap)
        return max(fmap[0][n-1], gmap[0][n-1])

arr = [7, 4, 16, 15, 1]
solution = Solution3()
score = solution.process(arr)
print(score)