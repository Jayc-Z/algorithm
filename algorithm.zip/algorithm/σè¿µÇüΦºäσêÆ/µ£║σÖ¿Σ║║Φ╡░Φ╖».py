
# 假设有排成一行的N个位置，记为：1~N，N一定大于或等于2
# 开始时机器人在其中的M位置上(M一定是1~N中的一个)
# 如果机器人来到1的位置，那么下一步只能往右来到2的位置
# 如果机器人来到N的位置，那么下一步只能往左来到N-1的位置
# 如果机器人来到中间位置，那么下一步可以往左走或者往右走
# 规定机器人开始在M位置，必须走K步，最终能来到P位置(P也是1~N中的一个)的方法有多少种

import sys
sys.setrecursionlimit(100000) #例如这里设置为十万

class Solution:
    # 1.暴力递归
    def process1(self, cur, res, aim, N):
        '''
        :param cur: 当前位置
        :param res: 剩余步数
        :param aim: 目标位置
        :param N: 总长度
        :return: 方法数
        '''
        if res == 0:
            return 1 if cur == aim else 0
        if cur == 1:
            return self.process1(2, res - 1, aim, N)
        if cur == N:
            return self.process1(N - 1, res - 1, aim, N)
        return self.process1(cur - 1, res - 1, aim, N) + self.process1(cur + 1, res - 1, aim, N)

    # 2.傻缓存（带递归的dp）
    def process1_(self, cur, res, aim, N, dp):
        '''
        :param cur: 当前位置
        :param res: 剩余步数
        :param aim: 目标位置
        :param N: 总长度
        :return: 方法数
        '''
        if res == 0:
            return 1 if cur == aim else 0
        if cur == 1:
            return self.process1_(2, res - 1, aim, N, dp)
        if cur == N:
            return self.process1_(N - 1, res - 1, aim, N, dp)
        return self.process1_(cur - 1, res - 1, aim, N, dp) + self.process1_(cur + 1, res - 1, aim, N, dp)

    def process2(self, cur, res, aim, N):
        '''
        :param cur: 当前位置
        :param res: 剩余步数
        :param aim: 目标位置
        :param N: 总长度
        :return: 方法数
        '''
        dp = [[-1 for _ in range(res+1)] for _ in range(N+1)]
        if dp[res][cur] != -1:
            return dp[res][cur]
        ans = 0
        if res == 0:
            ans = 1 if cur == aim else 0
        if cur == 1:
            ans = self.process1_(2, res - 1, aim, N, dp)
        if cur == N:
            ans = self.process1_(N - 1, res - 1, aim, N, dp)
        ans = self.process1_(cur - 1, res - 1, aim, N, dp) + self.process1_(cur + 1, res - 1, aim, N, dp)
        dp[res][cur] = ans
        return ans

    # 3.找依赖关系，填dp表
    def dp_process(self, start, k, aim, N):
        dp = [[0 for _ in range(k + 1)] for _ in range(N + 1)]  # 生成N+1行,k+1列的dp表
        dp[aim][0] = 1  #第0列填好！
        for rest in range(1, k+1):  # rest从第1列开始遍历
            dp[1][rest] = dp[2][rest-1]   # cur==1，只依赖cur=2
            for cur in range(2, N):   # cur从第2行开始遍历
                dp[cur][rest] = dp[cur-1][rest-1] + dp[cur+1][rest-1]
            dp[N][rest] = dp[N-1][rest-1]  # cur==N，只依赖Cur=N-1
        return dp[start][k]

start, k, aim, N = 2, 4, 4, 7
solution = Solution()
out = solution.dp_process(start, k, aim, N)
print(out)
