# 使用一般的列表结构即可实现栈
    # 进栈：li.append
    # 出栈：li.pop
    # 取栈顶：li[-1]

class Stack:
    def __init__(self):
        self.stack = []

    def push(self, x):
        self.stack.append(x)

    def pop(self):
        return self.stack.pop()

    def get_top(self):
        if len(self.stack) > 0:
            return self.stack[-1]
        else:
            return None

# stack = Stack()
# stack.push(1)
# stack.push(2)
# stack.push(3)
# print(stack.pop())

# 括号匹配问题
'''
[(){}()[]]
'''

def parentheses_match(stack, parentheses_str):
    parentheses_dict = {"{":"}",
                        "[":"]",
                        "(":")"}
    inversed_parentheses_dict = dict(zip(parentheses_dict.values(), parentheses_dict.keys()))
    # for loop string
    for p in parentheses_str:
        if p in parentheses_dict.keys():  # push left_parentheses in stack
            stack.push(p)
        elif p in parentheses_dict.values():  # pop right_parentheses out stack if stack_top match
            stack_top = stack.get_top()
            if stack_top == inversed_parentheses_dict[p]:
                stack.pop()
        else:
            continue
    if stack.get_top():
        print("括号不匹配")
    else:
        print("括号匹配")

stack = Stack()
parentheses_str = "[(1){33]3[}(212)[]]"
parentheses_match(stack, parentheses_str)






