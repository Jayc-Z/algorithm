'''
一个象棋的棋盘，然后把整个棋盘放入第一象限，棋盘的最左下角是(0,0)位置，那么整个棋盘就是横坐标上9条线、纵坐标上10条线的区域。
给你三个 参数 x，y，k。返回“马”从(0,0)位置出发，必须走k步。最后落在(x,y)上的方法数有多少种?
'''


# x~[0, 9], y~[0, 10]

class Solution_:
    def MaxWays(self, x, y, k):
        if k == 0:
            return 0
        if x > 9 or y > 10 or x < 0 or y < 0:
            return 0
        return self.process(x, y, 0, 0, k)

    # 定义process，当前位置x，当前位置y，剩余步数k
    def process(self, x, y, cur_x, cur_y, res_k):
        if cur_x == x and cur_y == y and res_k == 0:
            return 1
        if (cur_x != x or cur_y != y) and res_k == 0:
            return 0

        # 没到终点，且k有剩余
        # case1.x+2, y+1
        ways = self.process(x, y, cur_x + 2, cur_y + 1, res_k - 1)
        # case2.x+1, y+2
        ways += self.process(x, y, cur_x + 1, cur_y + 2, res_k - 1)
        # case3. x-1, y-2
        ways += self.process(x, y, cur_x - 1, cur_y - 2, res_k - 1)
        # case4. x-2, y-1
        ways += self.process(x, y, cur_x - 2, cur_y - 1, res_k - 1)
        # case...
        ways += self.process(x, y, cur_x - 2, cur_y + 1, res_k - 1)
        ways += self.process(x, y, cur_x - 1, cur_y + 2, res_k - 1)
        ways += self.process(x, y, cur_x + 2, cur_y - 1, res_k - 1)
        ways += self.process(x, y, cur_x + 1, cur_y - 2, res_k - 1)

        return ways


class Solution:
    def MaxWays(self, x, y, k):
        def pick(x, y, res_k, dp):
            if x < 0 or x > 9 or y < 0 or y > 10:
                return 0
            return dp[x][y][res_k]

        if x > 9 or y > 10 or x < 0 or y < 0:
            return 0
        dp = [[[0 for _ in range(k + 1)] for _ in range(11)] for _ in range(10)]
        dp[x][y][0] = 1
        for res_k in range(1, k + 1):
            for cur_x in range(10):
                for cur_y in range(11):
                    if cur_x == 0 and cur_y == 0:
                        dp[0][0][0] = 1
                    elif cur_x == x and cur_y == y:
                        dp[cur_x][cur_y][0] = 1
                    else:
                        dp[cur_x][cur_y][0] = 0
                        ways = pick(cur_x + 2, cur_y + 1, res_k - 1, dp)
                        # case2.x+1, y+2
                        ways += pick(cur_x + 1, cur_y + 2, res_k - 1, dp)
                        # case3. x-1, y-2
                        ways += pick(cur_x - 1, cur_y - 2, res_k - 1, dp)
                        # case4. x-2, y-1
                        ways += pick(cur_x - 2, cur_y - 1, res_k - 1, dp)
                        # case...
                        ways += pick(cur_x - 2, cur_y + 1, res_k - 1, dp)
                        ways += pick(cur_x - 1, cur_y + 2, res_k - 1, dp)
                        ways += pick(cur_x + 2, cur_y - 1, res_k - 1, dp)
                        ways += pick(cur_x + 1, cur_y - 2, res_k - 1, dp)
                        dp[cur_x][cur_y][res_k] = ways

        return dp[0][0][k]


if __name__ == '__main__':
    x, y, k = 3, 1, 6
    solution = Solution_()
    res = solution.MaxWays(x, y, k)
    print(res)

    solution = Solution()
    res = solution.MaxWays(x, y, k)
    print(res)

    dp = [[[0 for _ in range(2)] for _ in range(3)] for _ in range(4)]
    dp2 = [[0 for _ in range(2)] for _ in range(3)]



