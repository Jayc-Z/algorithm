class Solution(object):
    def minWindow(self, s, t):
        """
        :type s: str
        :type t: str
        :rtype: str
        """
        if len(t) > len(s):
            return
        if t == s:
            return t
        t_hashtable = dict()
        for _ in t:
            if _ not in t_hashtable:
                t_hashtable[_] = t.count(_)
        index_list = []
        for i in range(len(s)):
            if s[i] in t_hashtable:
                j = i + 1
                values = list(t_hashtable.values())
                while max(values) > 0 and j < len(s):
                    s_item = s[j]
                    if s_item in t_hashtable:
                        t_hashtable[s_item] -= 1
                        values = list(t_hashtable.values())
                    j += 1
                index_list.append((i, j, j - i))
                for z in t:
                    t_hashtable[z] = t.count(z)
        min_d = len(s)
        min_s = ""
        for (i, j, d) in index_list:
            if d < min_d:
                min_d = d
                min_s = s[i: j+1]
        return min_s

s = "ADOBECODEBANC"
t = "ABC"
sol = Solution()
min_s = sol.minWindow(s, t)
print(min_s)