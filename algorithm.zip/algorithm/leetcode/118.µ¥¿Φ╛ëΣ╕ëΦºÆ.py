'''
给定一个非负整数 numRows，生成「杨辉三角」的前 numRows 行。
在「杨辉三角」中，每个数是它左上方和右上方的数的和。
'''
'''
输入: numRows = 5
输出: [[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]]
'''
class Solution(object):
    def generate(self, numRows):
        """
        :type numRows: int
        :rtype: List[List[int]]
        """
        if numRows == 0:
            return []
        if numRows == 1:
            return [[1]]
        if numRows == 2:
            return [[1], [1,1]]
        # numrows >= 3
        res = [[1], [1,1]]
        for i in range(1, numRows - 1):
            # 下一行长度为i+2
            new_row = [1 for i in range(i+2)]
            # 取res最后一个
            tail_res = res[-1]
            # 遍历new_row列表1～i+1
            for j in range(1, i+1):
                new_row[j] = tail_res[j-1] + tail_res[j]
            res.append(new_row)
        return res

if __name__ == '__main__':
    numRows = 5
    solution = Solution()
    res = solution.generate(numRows)
    print(res)