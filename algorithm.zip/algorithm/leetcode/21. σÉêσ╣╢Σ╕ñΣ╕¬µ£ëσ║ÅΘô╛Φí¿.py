# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def mergeTwoLists(self, list1, list2):
        """
        :type list1: Optional[ListNode]
        :type list2: Optional[ListNode]
        :rtype: Optional[ListNode]
        """
        if list1 == None or list2 == None:
            return list1 if list2 == None else list2
        # head 是开头是小的
        head = list1 if list2.val > list1.val else list2
        cur1 = head.next
        cur2 = list2 if head == list1 else list1
        pre = head
        while list1 != None and list2 != None:
            if cur1.val <= cur2.val:
                pre.next = cur1
                cur1 = cur1.next
            else:
                pre.next = cur2
                cur2 = cur2.next
            pre = pre.next
        pre.next = list2 if list1 == None else list1

        return head

if __name__ == '__main__':
    l1 = [1, 2, 4]
    l2 = [1, 3, 4]
    solution = Solution()
    res = solution.mergeTwoLists(l1, l2)
