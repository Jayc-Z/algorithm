'''
给定两个字符串 text1 和 text2，返回这两个字符串的最长 公共子序列 的长度。如果不存在 公共子序列 ，返回 0 。

一个字符串的 子序列 是指这样一个新的字符串：它是由原字符串在不改变字符的相对顺序的情况下删除某些字符（也可以不删除任何字符）后组成的新字符串。

例如，"ace" 是 "abcde" 的子序列，但 "aec" 不是 "abcde" 的子序列。
两个字符串的 公共子序列 是这两个字符串所共同拥有的子序列。
'''
'''
输入：text1 = "abcde", text2 = "ace" 
输出：3  
解释：最长公共子序列是 "ace" ，它的长度为 3 。
'''

class Solution_:
    def longestCommonSubsequence(self, text1, text2):
        if len(text1) == 0 or len(text2) == 0:
            return 0
        return self.process(text1, text2, len(text1) - 1, len(text2) - 1)

    # 关注 text1[0,...., i] 与 text2[0,..., j]最长公共子序列
    def process(self, text1, text2, i, j):
        if i == 0 and j == 0:
            if text1[i] == text2[j]:
                return 1
            else:
                return 0
        if i == 0 and j != 0:
            if text1[i] == text2[j]:
                return 1
            else:
                return self.process(text1, text2, i, j - 1)
        if j == 0 and i != 0:
            if text1[i] == text2[j]:
                return 1
            else:
                return self.process(text1, text2, i - 1, j)
        # i、j != 0
        else:
            # 可能性1， i不是，j可能是末尾
            p1 = self.process(text1, text2, i - 1, j)
            # 可能性2，i可能是，j不是
            p2 = self.process(text1, text2, i, j - 1)
            # 可能性3，i j 都是末尾
            p3 = 0
            if text1[i] == text2[j]:
                p3 = 1 + self.process(text1, text2, i - 1, j - 1)
        return max(max(p1, p2), p3)

# dp
class Solution:
    def longestCommonSubsequence(self, text1, text2):
        if len(text1) == 0 or len(text2) == 0:
            return 0
        # i 做行 所以放外面
        dp = [[0 for _ in range(len(text2))] for _ in range(len(text1))]
        dp[0][0] = 1 if text1[0] == text2[0] else 0
        for i in range(1, len(text1)):
            dp[i][0] = 1 if text1[i] == text2[0] else dp[i-1][0]
        for j in range(1, len(text2)):
            dp[0][j] = 1 if text1[0] == text2[j] else dp[0][j-1]

        for i in range(1, len(text1)):
            for j in range(1, len(text2)):
                p1 = dp[i - 1][j]
                p2 = dp[i][j - 1]
                p3 = 0
                if text1[i] == text2[j]:
                    p3 = 1 + dp[i - 1][j - 1]
                dp[i][j] = max(max(p1, p2), p3)

        return dp[len(text1) - 1][len(text2) - 1]

if __name__ == '__main__':
    text1 = "abcde"
    text2 = "ace"
    solution = Solution_()
    res = solution.longestCommonSubsequence(text1, text2)
    print(res)

    solution = Solution()
    res = solution.longestCommonSubsequence(text1, text2)
    print(res)

    # dp = [[0 for _ in range(len(text1))] for _ in range(len(text2))]  # len(text2)行，len(text1)列
    # dp[0][1] = 1  # 给第0行 第1列赋值
    # dp[1][0] = 2
    # for dp_ in dp:
    #     print(dp_)