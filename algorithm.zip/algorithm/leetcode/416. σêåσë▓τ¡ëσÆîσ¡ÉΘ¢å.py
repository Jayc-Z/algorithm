'''给你一个 只包含正整数 的 非空 数组 nums 。请你判断是否可以将这个数组分割成两个子集，使得两个子集的元素和相等。

'''

'''
输入：nums = [1,5,11,5]
输出：true
解释：数组可以分割成 [1, 5, 5] 和 [11] 。
'''

# 我的分析：先求总和，递归找到一半总和值的子序列
class Solution(object):
    def canPartition(self, nums):
        """
        :type nums: List[int]
        :rtype: bool
        """
        n = len(nums)
        if n <= 1:
            return False
        if n == 2:
            if nums[0] == nums[1]:
                return True
            else:
                return False

    # [L, ... ,R]之和是否是总值一半
    def process(self, nums, L, R):
        nums_sum = sum(nums)
        if L == R:
            if nums[L] == nums_sum / 2:
                return True
            else:
                return False
        if

