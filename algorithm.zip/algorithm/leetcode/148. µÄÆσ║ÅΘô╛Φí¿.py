'''
给你链表的头结点 head ，请将其按 升序 排列并返回 排序后的链表
'''

# Definition for singly-linked list.
class ListNode(object):
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

class Solution(object):
    def sortList(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        length = 0
        cur = ListNode(0, head)
        while cur:
            cur = cur.next
            length += 1
        if length <= 1:
            return head
        return self.process(head, 0, length-1)

    def process(self, head, L, R):
        # base case
        if L == R:
            return
        mid = (L + R) // 2
        self.process(head, L, mid)
        self.process(head, mid+1, R)
        self.merge(head, L, mid, R)

    def merge(self, head, L, mid, R):
        help = [0 for _ in range(R - L + 1)]
        


