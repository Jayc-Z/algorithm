'''
给你一个满足下述两条属性的 m x n 整数矩阵：

每行中的整数从左到右按非递减顺序排列。
每行的第一个整数大于前一行的最后一个整数。
给你一个整数 target ，如果 target 在矩阵中，返回 true ；否则，返回 false 。
'''
'''
输入：matrix = [[1,3,5,7],[10,11,16,20],[23,30,34,60]], target = 13
输出：false
'''
class Solution(object):
    def searchMatrix(self, matrix, target):
        """
        :type matrix: List[List[int]]
        :type target: int
        :rtype: bool
        """
        nums = []
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
               nums.append(matrix[i][j])
        n = len(nums)
        L = 0
        R = n - 1
        mid = (L + R) // 2
        while L <= R:
            if nums[mid] > target:
                R = mid - 1
                mid = (L + R) // 2
            elif nums[mid] < target:
                L = mid + 1
                mid = (L + R) // 2
            else:
                return True
        else:
            return False



if __name__ == '__main__':
    matrix = [[1, 3, 5, 7], [10, 11, 16, 20], [23, 30, 34, 60]]
    target = 13
    solution = Solution()
    res = solution.searchMatrix(matrix, target)
    print(res)