'''
给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
'''

# Definition for singly-linked list.
class ListNode(object):
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next
class Solution(object):
    def removeNthFromEnd(self, head, n):
        """
        :type head: ListNode
        :type n: int 倒数第n
        :rtype: ListNode
        """
        length = 0
        res = ListNode(0, head)
        cur = res
        while cur:
            cur = cur.next
            length += 1
        cur = res
        while length != n + 1:
            cur = cur.next
            length -= 1
        cur.next = cur.next.next
        return res.next
    
if __name__ == '__main__':
    head = [1, 2, 3, 4, 5]
    n = 2
    solution = Solution()
    res = solution.removeNthFromEnd(head, n)
