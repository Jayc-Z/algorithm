class Solution(object):
    def groupAnagrams(self, strs):
        """
        :type strs: List[str]
        :rtype: List[List[str]]
        """
        hashtable = dict()
        for st in strs:
            key = "".join(sorted(st))
            if key not in hashtable:
                hashtable[key] = [st]
            else:
                hashtable[key].append(st)

        return list(hashtable.values())

strs = ["eat", "tea", "tan", "ate", "nat", "bat"]
sol = Solution()
sol.groupAnagrams(strs)