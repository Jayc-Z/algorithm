'''
你是一个专业的小偷，计划偷窃沿街的房屋。
每间房内都藏有一定的现金，影响你偷窃的唯一制约因素就是相邻的房屋装有相互连通的防盗系统，如果两间相邻的房屋在同一晚上被小偷闯入，系统会自动报警。
给定一个代表每个房屋存放金额的非负整数数组，计算你 不触动警报装置的情况下 ，一夜之内能够偷窃到的最高金额。
'''

'''
输入：[1,2,3,1]
输出：4
解释：偷窃 1 号房屋 (金额 = 1) ，然后偷窃 3 号房屋 (金额 = 3)。
     偷窃到的最高金额 = 1 + 3 = 4 。
'''
class Solution:
    def Maxvalue(self, nums):
        if len(nums) == 0:
            return 0
        if len(nums) <= 2:
            return max(nums)
        return self.process(nums, 0)

    def process(self, nums, i):
        n = len(nums)
        if i > n-1:
            return 0
        if i == n-1:
            return nums[i]
        # [1, ..., i-1]不考虑
        # [i, ..... , n-1]返回最大
        # 可能性1，选择偷当前i值
        p1 = nums[i] + self.process(nums, i+2)
        # 可能性2，不选择当前i值
        p2 = self.process(nums, i+1)
        return max(p1, p2)

class dp_Solution:
    def Maxvalue(self, nums):
        if len(nums) == 0:
            return 0
        if len(nums) <= 2:
            return max(nums)
        n = len(nums)
        dp = [0 for _ in range(n+1)]
        dp[n-1] = nums[n-1]
        for i in range(n-2, -1, -1):
            p1 = nums[i] + dp[i+2]
            p2 = dp[i+1]
            dp[i] = max(p1, p2)
        return dp[0]

if __name__ == '__main__':
    nums = [2, 1, 1, 2]
    solution = Solution()
    res = solution.Maxvalue(nums)
    print(res)

    dp_solution = dp_Solution()
    res = dp_solution.Maxvalue(nums)
    print(res)
