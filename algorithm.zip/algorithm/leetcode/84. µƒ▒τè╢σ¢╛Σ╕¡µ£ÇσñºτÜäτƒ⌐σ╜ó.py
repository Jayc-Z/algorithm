class Solution(object):
    def largestRectangleArea(self, heights):
        """
        :type heights: List[int]
        :rtype: int
        """
        stack = []
        stack.append(heights[0])
        id_stack = []
        id_stack.append(0)
        for i, val in enumerate(heights[1:]):
            if val < stack[-1] and stack:
                temp_k = len(stack) + 1
                if temp_k * val < min(stack) * len(stack):
                    continue
                elif temp_k * val >= min(stack) * len(stack) and i - 1 != id_stack[-1]:
                    continue
            stack.pop()
            stack.append(val)
            print(stack)
        return min(stack) * len(stack)

heights = [2, 0 ,2]
sol = Solution()
out = sol.largestRectangleArea(heights)
print(out)


