'''
给你一个字符串 s ，找出其中最长的回文子序列，并返回该序列的长度。

子序列定义为：不改变剩余字符顺序的情况下，删除某些字符或者不删除任何字符形成的一个序列。
'''
'''
输入：s = "bbbab"
输出：4
解释：一个可能的最长回文子序列为 "bbbb" 。
'''

class Solution_(object):
    def longestPalindromeSubseq(self, s):
        """
        :type s: str
        :rtype: int
        """
        if len(s) <= 1:
            return len(s)
        if len(s) == 2:
            if s[0] == s[1]:
                return 2
            else:
                return 0
        return self.process(s, 0, len(s) - 1)

    # 关注s[L,.., R]之间的最长回文子序列
    def process(self, s, L, R):
        if L == R:
            return 1
        if L == R - 1:
            if s[L] == s[R]:
                return 2
            else:
                return 1
        # L < R - 1
        # 可能性1.L不是回文起始序列，R可能是
        p1 = self.process(s, L + 1, R)
        # 可能性2.L可能是，R不是
        p2 = self.process(s, L, R - 1)
        # 可能性3.L不是，R不是
        p3 = self.process(s, L + 1, R - 1)
        # 可能性4.L是，R是
        p4 = 0
        if s[L] == s[R]:
            p4 = 2 + self.process(s, L + 1, R - 1)
        return max(max(p1, p2), max(p3, p4))

class Solution:
    def longestPalindromeSubseq(self, s):
        if len(s) <= 1:
            return len(s)
        if len(s) == 2:
            if s[0] == s[1]:
                return 2
            else:
                return 1
        n = len(s)
        dp = [[0 for _ in range(n)] for _ in range(n)]
        dp[n-1][n-1] = 1
        for i in range(n-1):
            dp[i][i] = 1
            dp[i][i+1] = 2 if s[i] == s[i+1] else 1
        for i in range(n - 3, -1, -1):
            for j in range(i + 2, n):
                p1 = dp[i + 1][j]
                p2 = dp[i][j - 1]
                p3 = dp[i + 1][j - 1]
                p4 = 0
                if s[i] == s[j]:
                    p4 = 2 + dp[i + 1][j - 1]
                dp[i][j] = max(max(p1, p2), max(p3, p4))
        return dp[0][n - 1]

if __name__ == '__main__':
    s = "bbbab"
    solution = Solution()
    res = solution.longestPalindromeSubseq(s)
    print(res)