class ListNode:
    def __init__(self, x):
        self.val = x
        self.next = None

class Solution:
    def getIntersectionNode(self, headA, headB):
        """
        :type head1, head1: ListNode
        :rtype: ListNode
        """
        lenA = 0
        lenB = 0
        curA, curB = headA, headB
        while curA != None:
            lenA += 1
            curA = curA.next
        while curB != None:
            lenB += 1
            curB = curB.next
        if lenB > lenA:
            lenA, lenB = lenB, lenA
            headA, headB = headB, headA
        curA, curB = headA, headB
        gap = lenA - lenB
        while gap != 0:
            curA = curA.next
            gap -= 1
        while curA != None:
            if curA == curB:
                return "Intersected at '%d'" % curA
            else:
                curA = curA.next
                curB = curB.next
        else:
            return None


