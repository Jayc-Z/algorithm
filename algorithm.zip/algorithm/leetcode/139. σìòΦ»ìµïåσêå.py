'''
给你一个字符串 s 和一个字符串列表 wordDict 作为字典。请你判断是否可以利用字典中出现的单词拼接出 s 。

注意：不要求字典中出现的单词全部都使用，并且字典中的单词可以重复使用。
'''
'''
输入: s = "leetcode", wordDict = ["leet", "code"]
输出: true
解释: 返回 true 因为 "leetcode" 可以由 "leet" 和 "code" 拼接成。
'''

class Solution_(object):
    def wordBreak(self, s, wordDict):
        """
        :type s: str
        :type wordDict: List[str]
        :rtype: bool
        """
        if len(s) == 0 or len(wordDict) == 0:
            return False
        return True if self.process(s, wordDict) == 1 else False

    def process(self, s, wordDict):
        s_zerolike = "0" * len(s)
        if s == s_zerolike:
            return 1
        minn = float("inf")
        for word in wordDict:
            if word in s:
                rest_s = s.replace(word, "0" * len(word), 1)
                minn = min(minn, self.process(rest_s, wordDict))
        return minn

class Solution:
    def wordBreak(self, s, wordDict):
        """
        :type s: str
        :type wordDict: List[str]
        :rtype: bool
        """
        if len(s) == 0 or len(wordDict) == 0:
            return False
        dp = []
        for s_item in s:
            dp.append(s_item)



        return True if dp[s] == 1 else False

if __name__ == '__main__':
    s = "leetcode"
    wordDict = ["leet","code"]
    solution = Solution_()
    res = solution.wordBreak(s, wordDict)
    print(res)

    solution = Solution()
    res = solution.wordBreak(s, wordDict)
    print(res)