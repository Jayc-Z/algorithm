'''
给你一个链表，两两交换其中相邻的节点，并返回交换后链表的头节点。你必须在不修改节点内部的值的情况下完成本题（即，只能进行节点交换）。
'''
# Definition for singly-linked list.
class ListNode(object):
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

class Solution(object):
    def swapPairs(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        start = ListNode(0, head)
        end = self.getKgroup_end(start, 2)
        if end == None:
            return head
        # 凑齐第一组了!
        head = end   # head指向第一组最后一个
        self.reverse(start, end)
        # 上一组的结尾节点
        lastEnd = ListNode(0, start)
        while lastEnd.next != None:
            start = lastEnd.next
            end = self.getKgroup_end(start, 2)
            self.reverse(start, end)
            lastEnd.next = end
            lastEnd = start

        return head

    def getKgroup_end(self, start, k):
        while start and k > 0:
            start = start.next
            k -= 1
        return start

    def reverse(self, start, end):
        end = end.next
        pre = ListNode(0, None)
        cur = ListNode(0, start)
        temp = ListNode(0, None)
        while cur != end:
            temp = cur.next
            cur.next = pre
            pre = cur
            cur = temp
        start.next = end


